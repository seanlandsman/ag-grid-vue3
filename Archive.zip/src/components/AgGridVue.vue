<script setup lang="ts">
import type { AgEventType, GridApi, GridOptions, IRowNode, Module } from 'ag-grid-community';
import {
  ALWAYS_SYNC_GLOBAL_EVENTS,
  ComponentUtil,
  _combineAttributesAndGridOptions,
  _processOnChange,
  _warnOnce,
  createGrid,
} from 'ag-grid-community';

import {markRaw, onMounted, ref, toRaw, useTemplateRef} from 'vue';
import type { Ref } from 'vue'

export interface Properties {
  [propertyName: string]: any;
}

defineProps({
  gridOptions: {
    type: GridOptions,
    default: {}
  },
  // @START_PROPS@
  // @END_PROPS@
})

// interface Props {
//   gridOptions?: GridOptions,
//   modules?:Module[]
// }
//
// const {
//   // @START_PROPS@
//   // @END_PROPS@
//   gridOptions = {},
//   modules = []
// } = defineProps<Props>()
//
const rootRef = useTemplateRef<HTMLDivElement>('root')

const api: Ref<GridApi | undefined> = ref(undefined);
const gridCreated: Ref<boolean> = ref(false);
const isDestroyed: Ref<boolean> = ref(false);
const gridReadyFired: Ref<boolean> = ref(false);
// const emitRowModel?: () => void | null = ref(undefined);
// const batchTimeout: number | null;


const globalEventListenerFactory = (restrictToSyncOnly?: boolean) => {
  return (eventType: AgEventType) => {
    if (isDestroyed) {
      return;
    }

    if (eventType === 'gridReady') {
      gridReadyFired.value = true;
    }

    const alwaysSync = ALWAYS_SYNC_GLOBAL_EVENTS.has(eventType);
    if ((alwaysSync && !restrictToSyncOnly) || (!alwaysSync && restrictToSyncOnly)) {
      return;
    }

    // this.updateModelIfUsed(eventType);
  };
}

const processChanges = (propertyName: string, currentValue: any, previousValue: any) => {
  if (gridCreated) {
    // if (skipChange(propertyName, currentValue, previousValue)) {
    //   return;
    // }

    const options: Properties = {
      [propertyName]:
          propertyName === 'rowData'
              ? Object.isFrozen(currentValue)
                  ? currentValue
                  : markRaw(toRaw(currentValue))
              : currentValue,
    };
    // decouple the row data - if we don't when the grid changes row data directly that'll trigger this component to react to rowData changes,
    // which can reset grid state (ie row selection)
    _processOnChange(options, api as any);
  }
}

onMounted(() => {
  const gridParams = {
    globalEventListener: globalEventListenerFactory().bind(this),
    globalSyncEventListener: globalEventListenerFactory(true).bind(this),
    // frameworkOverrides: new VueFrameworkOverrides(this),
    // providedBeanInstances: {
    //   frameworkComponentWrapper,
    // },
    modules
  };

  const options = markRaw(_combineAttributesAndGridOptions(toRaw(gridOptions), {

  }));

  api.value = createGrid(rootRef.value!, options, gridParams);
  gridCreated.value = true;

})
</script>

<template>
  <div ref="root"></div>
</template>

<style scoped>
</style>
