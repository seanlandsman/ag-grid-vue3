// import { describe, it, expect } from 'vitest'
//
// import { mount } from '@vue/test-utils'
// import AgGridVue from '../AgGridVue.vue'
//
// describe('AgGridVue3', () => {
//   it('renders properly', () => {
//     const wrapper = mount(AgGridVue, { props: { msg: 'Hello Vitest' } })
//     expect(wrapper.text()).toContain('Hello Vitest')
//   })
// })
