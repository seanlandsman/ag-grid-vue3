import AgGridVue from './components/AgGridVue.vue'
export default AgGridVue;
